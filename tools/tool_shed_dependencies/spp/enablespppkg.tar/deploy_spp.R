install.packages("bitops",dependencies=TRUE, repos="http://cran.us.r-project.org")
install.packages("caTools",dependencies=TRUE, repos="http://cran.us.r-project.org")
install.packages("snow",dependencies=TRUE, repos="http://cran.us.r-project.org")
install.packages('/mnt/galaxyData/tmp/spp_1.10.1.tar.gz',dependencies=TRUE)
