PATH=/mnt/galaxyTools/tools/macs/1.4.1/bin:$PATH
PYTHONPATH=/mnt/galaxyTools/tools/macs/1.4.1/lib/python2.6/site-packages:$PYTHONPATH
