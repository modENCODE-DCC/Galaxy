PATH=/mnt/galaxyTools/tools/peakranger/1.16/bin:$PATH

