PATH=/mnt/galaxyTools/tools/samtools/0.1.12:$PATH
